# NEON STRIKE — Standalone Multiplayer Server & Shared Physics

This archive contains the authoritative Node.js WebSocket multiplayer server, persistent player profile store, and deterministic shared FPS physics, maps, and weapon specifications.

## Included Modules

- `server.ts` — Express HTTP API + WebSocket (`/ws`) server entrypoint
- `src/server/GameServer.ts` — 20Hz authoritative match loop, public matchmaking, private room codes, server-side raycast hit validation, and respawning
- `src/server/ProfileStore.ts` — File-backed persistent player stats, XP/leveling, and cosmetic skin validation
- `src/shared/physics.ts` — Shared FPS movement, ramp traversal, AABB collision, and head/body hitbox raycasting
- `src/shared/maps.ts` — Arena geometry, ramps, and spawn points for NEON DISTRICT and ORBITAL FOUNDRY
- `src/shared/weapons.ts` — Weapon stats and cosmetic skins
- `src/shared/types.ts` — Shared WebSocket protocol and game state types

## Quick Start

1. Install dependencies (Node.js 22+ recommended):
   ```bash
   npm install
   ```
2. Start the server:
   ```bash
   NODE_ENV=production npm start
   ```
   (Or run `npm run dev` with `tsx`.)

3. Connect clients to:
   - HTTP API: `http://localhost:3000/api/health`
   - WebSocket: `ws://localhost:3000/ws`
